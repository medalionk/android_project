package ee.ut.demo.mvp.view;

public interface View {
}
