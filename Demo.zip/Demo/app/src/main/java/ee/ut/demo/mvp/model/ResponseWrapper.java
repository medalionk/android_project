package ee.ut.demo.mvp.model;

public class ResponseWrapper<T> {
    public T body;
}
